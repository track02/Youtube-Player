# Youtube-Skipper

Firefox extension to  provide video controls for youtube allowing video control from any tab.


## ToDo

- Tidy up / final testing
- Repackage and upload

## Other

- Icons from https://material.io/icons/
- Bootstrap CSS https://v4-alpha.getbootstrap.com/
- Font Awesome http://fontawesome.io/icons/
