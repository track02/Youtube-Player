# Youtube-Skipper

Firefox extension to  provide video controls for youtube allowing video control from any tab.


## Other

- Icon from https://material.io/icons/
- Bootstrap CSS https://v4-alpha.getbootstrap.com/
- Font Awesome http://fontawesome.io/icons/
